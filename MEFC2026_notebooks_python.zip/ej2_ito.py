# %% [markdown]
# # Ejercicio 2 — Cálculo de Itô
#
# **MEFC 2026 · Procesos estocásticos**
#
# Tres apartados: la condición de martingala para el cociente de dos procesos, la resolución de
# una integral de Itô y el estudio de un proceso cuadrático. Los desarrollos son analíticos; el
# notebook los acompaña de comprobaciones numéricas.

# %%
import numpy as np
import matplotlib.pyplot as plt
from math import erf, sqrt, pi, exp

plt.rcParams["figure.dpi"] = 110
np.set_printoptions(precision=6, suppress=True)

# %% [markdown]
# ## Apartado 2.a — Condición de martingala para $X_t/N_t$
#
# Partimos de
#
# $$dX_t = \mu X_t\,dt + \sigma X_t\,dW_t^{(1)}, \qquad
#   dN_t = \tfrac12\sigma^2 N_t\,dt + \sigma N_t\,dW_t^{(2)}, \qquad
#   d\langle W^{(1)}, W^{(2)}\rangle_t = \rho\,dt$$
#
# ### Método 1: regla del cociente de Itô
#
# Para $Y_t = X_t/N_t$, aplicando Itô bidimensional a $f(x,n) = x/n$:
#
# $$dY_t = \frac{dX_t}{N_t} - \frac{X_t}{N_t^2}dN_t + \frac{X_t}{N_t^3}d\langle N\rangle_t
#          - \frac{1}{N_t^2}d\langle X,N\rangle_t$$
#
# Sustituyendo $d\langle N\rangle_t = \sigma^2 N_t^2 dt$ y $d\langle X,N\rangle_t = \rho\sigma^2 X_t N_t dt$:
#
# $$\frac{dY_t}{Y_t} = \Big(\mu + \tfrac12\sigma^2 - \rho\sigma^2\Big)dt
#                      + \sigma\big(dW_t^{(1)} - dW_t^{(2)}\big)$$
#
# Es martingala si y solo si la deriva se anula:
#
# $$\boxed{\;\mu = \sigma^2\Big(\rho - \tfrac12\Big)\;}$$
#
# ### Método 2: por las soluciones explícitas
#
# $X_t = X_0 e^{(\mu - \sigma^2/2)t + \sigma W^{(1)}_t}$ y $N_t = N_0 e^{\sigma W^{(2)}_t}$ (el
# coeficiente $\tfrac12\sigma^2$ de $N$ cancela exactamente su corrección de Itô). Entonces
# $Y_t = Y_0 e^{\alpha t + \beta B_t}$ con $\alpha = \mu - \tfrac12\sigma^2$ y
# $\beta = \sigma\sqrt{2(1-\rho)}$, porque
# $\operatorname{Var}(W^{(1)}_t - W^{(2)}_t) = 2(1-\rho)t$. Una exponencial así es martingala si y
# solo si $\alpha + \tfrac12\beta^2 = 0$, que da el mismo resultado.

# %%
def mu_martingala(sigma, rho):
    """Deriva que hace martingala el cociente X/N."""
    return sigma**2 * (rho - 0.5)


def simular_cociente(mu, sigma, rho, T=1.0, pasos=2000, caminos=200_000, semilla=1):
    """Simula Y_T = X_T/N_T por Euler sobre los brownianos correlacionados."""
    rng = np.random.default_rng(semilla)
    dt = T / pasos
    # W2 = rho*W1 + sqrt(1-rho^2)*W_indep
    logY = np.zeros(caminos)
    for _ in range(pasos):
        z1 = rng.standard_normal(caminos)
        z2 = rho * z1 + sqrt(max(0.0, 1 - rho**2)) * rng.standard_normal(caminos)
        dW1, dW2 = z1 * sqrt(dt), z2 * sqrt(dt)
        # d(log Y) = (mu - sigma^2/2)dt + sigma dW1 - (0)dt - sigma dW2 + correccion cruzada
        logY += (mu - 0.5 * sigma**2) * dt + sigma * (dW1 - dW2)
    return np.exp(logY)


sigma = 0.30
print(f"sigma = {sigma}\n")
print(f"{'rho':>6}{'mu teorica':>14}{'E[Y_1] simulado':>20}{'error estandar':>17}")
for rho in [-0.5, 0.0, 0.5, 0.9, 1.0]:
    mu = mu_martingala(sigma, rho)
    Y = simular_cociente(mu, sigma, rho, pasos=250, caminos=100_000, semilla=7)
    ee = Y.std(ddof=1) / sqrt(len(Y))
    print(f"{rho:>6.2f}{mu:>14.6f}{Y.mean():>20.6f}{ee:>17.6f}")

print("\nSi Y es martingala con Y_0 = 1, entonces E[Y_1] = 1.")
print("Con rho = 1 el cociente es exactamente constante: X y N tienen la misma dinamica.")

# %% [markdown]
# ## Apartado 2.b — La integral $I_t = \int_0^t (W_s^2 - s)\,dW_s$
#
# Siguiendo la indicación, aplicamos Itô a $W_t^3$:
#
# $$d(W_t^3) = 3W_t^2\,dW_t + 3W_t\,dt
#   \quad\Longrightarrow\quad \int_0^t W_s^2\,dW_s = \frac{W_t^3}{3} - \int_0^t W_s\,ds$$
#
# Y por partes sobre $sW_s$ (sin término de Itô, porque $\partial^2_{ww}(sw) = 0$):
#
# $$\int_0^t s\,dW_s = tW_t - \int_0^t W_s\,ds$$
#
# Al restar, las integrales de Riemann —que no tienen forma cerrada— se cancelan:
#
# $$\boxed{\;I_t = \frac{W_t^{3}}{3} - t\,W_t\;}$$
#
# **Verificación.** Si $f(t,w) = \tfrac13 w^3 - tw$, entonces $f_t = -w$, $f_w = w^2 - t$,
# $f_{ww} = 2w$, y por Itô
# $df = (-W_t + W_t)dt + (W_t^2 - t)dW_t = (W_t^2-t)dW_t$, que es el integrando pedido, con
# $f(0,0)=0$.
#
# Por la isometría de Itô, con $\mathbb E[W_s^4] = 3s^2$:
#
# $$\operatorname{Var}(I_t) = \int_0^t \big(3s^2 - 2s^2 + s^2\big)\,ds = \frac{2t^3}{3}$$

# %%
def comprobar_integral(T=1.0, pasos=4000, caminos=100_000, semilla=11):
    """Compara la suma de Itô discretizada con la formula cerrada W^3/3 - tW."""
    rng = np.random.default_rng(semilla)
    dt = T / pasos
    W = np.zeros(caminos)
    I = np.zeros(caminos)                       # suma de Riemann-Ito, integrando por la izquierda
    for k in range(pasos):
        t = k * dt
        dW = rng.standard_normal(caminos) * sqrt(dt)
        I += (W**2 - t) * dW                    # integrando evaluado en el extremo IZQUIERDO
        W += dW
    cerrada = W**3 / 3 - T * W
    return I, cerrada, W


I_sim, I_cerrada, W_T = comprobar_integral()
error = np.abs(I_sim - I_cerrada)

print(f"comparacion trayectoria a trayectoria (100.000 caminos, 4.000 pasos):")
print(f"  error absoluto medio  : {error.mean():.6f}")
print(f"  error absoluto maximo : {error.max():.6f}")
print(f"  desviacion tipica de I: {I_cerrada.std(ddof=1):.6f}")
print(f"\n  el error relativo medio es {error.mean() / I_cerrada.std(ddof=1):.4%} de la "
      f"desviacion tipica: es error de discretizacion, y tiende a cero al afinar la malla.")

print(f"\nmomentos de I_1:")
print(f"  E[I_1]   simulado {I_cerrada.mean():>10.6f}   teorico {0.0:>10.6f}")
print(f"  Var(I_1) simulado {I_cerrada.var(ddof=1):>10.6f}   teorico {2/3:>10.6f}")

# %% [markdown]
# ## Apartado 2.c — El proceso $M_t = \Big(\int_0^t s\,dW_s\Big)^2 - \dfrac{t^3}{3}$
#
# Llamemos $N_t = \int_0^t s\,dW_s$. Por ser el integrando determinista, $N$ es gaussiano centrado
# con variación cuadrática
#
# $$\langle N\rangle_t = \int_0^t s^2\,ds = \frac{t^3}{3},
#   \qquad N_t \sim \mathcal N\Big(0, \frac{t^3}{3}\Big), \qquad M_t = N_t^2 - \langle N\rangle_t$$
#
# ### 1) Dos demostraciones de que es martingala
#
# **Vía A — fórmula de Itô.** Con $f(t,n) = n^2 - t^3/3$: $f_t = -t^2$, $f_n = 2n$, $f_{nn} = 2$ y
# $dN_t = t\,dW_t$, luego
#
# $$dM_t = \Big(-t^2 + \tfrac12\cdot 2\cdot t^2\Big)dt + 2N_t\,dN_t = 2\,t\,N_t\,dW_t$$
#
# La deriva se anula idénticamente. Y es martingala verdadera, no solo local, porque
#
# $$\mathbb E\!\left[\int_0^t (2sN_s)^2 ds\right] = 4\int_0^t s^2\frac{s^3}{3}ds
#   = \frac{2t^6}{9} < \infty$$
#
# **Vía B — esperanza condicionada.** Para $u<t$, escribimos $N_t = N_u + \Delta$ con
# $\Delta = \int_u^t s\,dW_s$ independiente de $\mathcal F_u$ y de varianza $(t^3-u^3)/3$:
#
# $$\mathbb E[M_t \mid \mathcal F_u] = N_u^2 + \frac{t^3-u^3}{3} - \frac{t^3}{3}
#   = N_u^2 - \frac{u^3}{3} = M_u$$
#
# ### 2) Distribución y momentos
#
# $$\boxed{\;M_t = \frac{t^3}{3}\big(Z^2 - 1\big), \quad Z\sim\mathcal N(0,1)
#   \quad\Longrightarrow\quad M_t + \frac{t^3}{3} \sim \frac{t^3}{3}\chi^2_1\;}$$
#
# $$\mathbb E(M_t) = 0, \qquad \operatorname{Var}(M_t) = \frac{2t^6}{9},
#   \qquad \text{soporte } \Big[-\frac{t^3}{3}, \infty\Big)$$
#
# Para $t=1$: $\operatorname{Var}(M_1) = 2/9 = 0.2222$, asimetría $\sqrt8 = 2.8284$.

# %%
def simular_trayectorias_M(T=1.0, pasos=500, caminos=6, semilla=3):
    """Trayectorias completas de M_t sobre una malla."""
    rng = np.random.default_rng(semilla)
    dt = T / pasos
    t = np.linspace(0, T, pasos + 1)
    N = np.zeros((caminos, pasos + 1))
    for k in range(pasos):
        # integrando evaluado en el extremo IZQUIERDO: convencion de Ito
        N[:, k + 1] = N[:, k] + t[k] * rng.standard_normal(caminos) * sqrt(dt)
    M = N**2 - t**3 / 3
    return t, M


t_malla, M_tray = simular_trayectorias_M(caminos=4)

fig, eje = plt.subplots(figsize=(9, 4))
for j in range(M_tray.shape[0]):
    eje.plot(t_malla, M_tray[j], lw=1.1)
eje.plot(t_malla, -t_malla**3 / 3, "k--", lw=1.4, label=r"cota inferior $-t^3/3$")
eje.axhline(0, color="grey", lw=.6)
eje.set(xlabel="t", ylabel="$M_t$", title="Trayectorias de $M_t$ (500 pasos)")
eje.legend(fontsize=9)
eje.grid(alpha=.3)
plt.tight_layout()
plt.show()

# %% [markdown]
# Las trayectorias pasan la mayor parte del tiempo pegadas a la cota $-t^3/3$, con excursiones
# ocasionales muy grandes hacia arriba: así es como una martingala tan asimétrica mantiene la
# media en cero.

# %%
# En t = 1 basta con M_1 = (Z^2 - 1)/3, porque N_1 ~ N(0, 1/3)
REPLICAS = 200_000
rng = np.random.default_rng(20260907)
Z = rng.standard_normal(REPLICAS)
M1 = (Z**2 - 1) / 3

asimetria = ((M1 - M1.mean())**3).mean() / M1.std()**3
ee_media = M1.std(ddof=1) / sqrt(REPLICAS)

print(f"COMPROBACION EMPIRICA EN t = 1   ({REPLICAS:,} replicas)\n")
print(f"{'magnitud':<22}{'simulado':>14}{'teorico':>14}")
print(f"{'E[M_1]':<22}{M1.mean():>14.6f}{0.0:>14.6f}")
print(f"{'Var(M_1)':<22}{M1.var(ddof=1):>14.6f}{2/9:>14.6f}")
print(f"{'desviacion tipica':<22}{M1.std(ddof=1):>14.6f}{sqrt(2)/3:>14.6f}")
print(f"{'asimetria':<22}{asimetria:>14.6f}{sqrt(8):>14.6f}")
print(f"{'minimo':<22}{M1.min():>14.6f}{-1/3:>14.6f}  (cota)")

ic = (M1.mean() - 1.96 * ee_media, M1.mean() + 1.96 * ee_media)
print(f"\nintervalo de confianza al 95 % para E[M_1]: [{ic[0]:.6f}, {ic[1]:.6f}]")
print(f"contiene el cero teorico: {ic[0] < 0 < ic[1]}")

# %%
# Cuantiles: empiricos frente a los de (Z^2-1)/3
from statistics import NormalDist

nd = NormalDist()
print(f"{'p':>6}{'empirico':>14}{'teorico':>14}")
for p in [0.01, 0.05, 0.25, 0.50, 0.75, 0.95, 0.99]:
    # cuantil de chi2_1: (Phi^{-1}((1+p)/2))^2
    q_teo = (nd.inv_cdf((1 + p) / 2) ** 2 - 1) / 3
    print(f"{p:>6.2f}{np.quantile(M1, p):>14.5f}{q_teo:>14.5f}")

# %%
# Histograma frente a la densidad teorica
rejilla = np.linspace(-1/3 + 1e-6, 3, 600)
densidad = 3 * np.exp(-(3 * rejilla + 1) / 2) / np.sqrt(2 * pi * (3 * rejilla + 1))

fig, eje = plt.subplots(figsize=(8.5, 4.2))
eje.hist(M1, bins=np.linspace(-1/3, 3, 90), density=True, alpha=.55,
         color="#7fb3d5", label=f"simulado ({REPLICAS:,})")
eje.plot(rejilla, densidad, color="#a02c2c", lw=1.8, label=r"densidad de $(Z^2-1)/3$")
eje.set(xlabel="$M_1$", ylabel="densidad", xlim=(-0.45, 3), ylim=(0, 5),
        title="Distribución de $M_1$")
eje.legend()
eje.grid(alpha=.3)
plt.tight_layout()
plt.show()

# %% [markdown]
# ### Comprobación de la propiedad de martingala
#
# Que la media sea cero no basta: hay que verificar $\mathbb E[M_1 \mid M_{0.5}] = M_{0.5}$.
# Simulamos pares $(M_{0.5}, M_1)$, los agrupamos por deciles de $M_{0.5}$ y comparamos la media
# condicional de $M_1$ en cada grupo. Si es martingala, los puntos caen sobre la recta $y = x$.

# %%
PARES = 100_000
rng = np.random.default_rng(4242)
# N_{0.5} ~ N(0, 0.5^3/3);  incremento independiente con varianza (1 - 0.5^3)/3
v_medio = 0.5**3 / 3
v_resto = (1 - 0.5**3) / 3
N_medio = rng.standard_normal(PARES) * sqrt(v_medio)
N_final = N_medio + rng.standard_normal(PARES) * sqrt(v_resto)
M_medio = N_medio**2 - v_medio
M_final = N_final**2 - 1 / 3

bordes = np.quantile(M_medio, np.linspace(0, 1, 11))
grupo = np.clip(np.digitize(M_medio, bordes[1:-1]), 0, 9)
x = np.array([M_medio[grupo == g].mean() for g in range(10)])
y = np.array([M_final[grupo == g].mean() for g in range(10)])
ee = np.array([M_final[grupo == g].std(ddof=1) / sqrt((grupo == g).sum()) for g in range(10)])

fig, eje = plt.subplots(figsize=(6.4, 5))
eje.errorbar(x, y, yerr=1.96 * ee, fmt="o", ms=5, capsize=3, color="#2a5783", label="simulación")
lim = [min(x.min(), y.min()) - .02, max(x.max(), y.max()) + .02]
eje.plot(lim, lim, "--", color="#a02c2c", lw=1.4, label="$y = x$ (martingala)")
eje.set(xlabel="$M_{0.5}$ (media del decil)", ylabel="media de $M_1$ en el decil",
        title="$E[M_1 \\mid M_{0.5}] = M_{0.5}$")
eje.legend()
eje.grid(alpha=.3)
plt.tight_layout()
plt.show()

desviacion = np.abs(y - x) / ee
print(f"desviacion maxima respecto a y = x: {desviacion.max():.2f} errores estandar")
print(f"(por debajo de 2 en todos los deciles, la propiedad se verifica)")

# %% [markdown]
# ## Resumen del ejercicio 2

# %%
print("2.a)  mu = sigma^2 (rho - 1/2)")
print("2.b)  I_t = W_t^3/3 - t W_t,   Var(I_t) = 2t^3/3")
print("2.c)  M_t es martingala (dM = 2t N_t dW, de cuadrado integrable)")
print(f"      M_t = (t^3/3)(chi2_1 - 1),  E[M_t] = 0,  Var(M_t) = 2t^6/9")
print(f"      en t = 1:  Var(M_1) = 2/9 = {2/9:.6f}  (simulado {M1.var(ddof=1):.6f})")
