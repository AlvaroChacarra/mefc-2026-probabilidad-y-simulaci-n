# %% [markdown]
# # Ejercicio 1 — Cadena de Markov de *ratings*
#
# **MEFC 2026 · Procesos estocásticos**
#
# Modelizamos el *rating* de una compañía como una cadena de Markov homogénea en tiempo
# discreto sobre ocho estados, con paso anual y matriz de transición $P$. El estado
# *Default* es absorbente.
#
# $$\mathbb P(R_n = j \mid R_0 = i) = (P^{\,n})_{ij}, \qquad P^{\,n} = P^{\,n-1} P$$
#
# ## Nota sobre los datos
#
# El fichero `matriz-ratings.xlsx` trae **nueve filas y ocho columnas**: las transiciones que
# parten del tramo inferior aparecen desdobladas en dos filas, «Caa» y «Ca-C», mientras que en
# las columnas ese tramo está agregado en un único estado «Caa-C».
#
# Consultada la incidencia con la profesora, el criterio indicado es que sobra una fila y que,
# al no haber información para ponderar la agregación, procede **suprimir una de las dos filas y
# asignar la que se conserve a los estados de salida Caa-C**, dejándolo anotado.
#
# Conservamos «Caa» y descartamos «Ca-C» porque el elemento mayor de «Caa» (0.51823) cae sobre la
# diagonal, igual que en las otras seis filas de rating, mientras que en «Ca-C» el mayor (0.76267)
# quedaría en la columna *Default*, lo que supondría un 76 % de default a un año para ese tramo.

# %%
import numpy as np
from pathlib import Path

np.set_printoptions(precision=6, suppress=True, linewidth=140)

ESTADOS = ["Aaa", "Aa", "A", "Baa", "Ba", "B", "Caa-C", "Default"]
N = 8          # número de estados
D = 7          # índice del estado Default (absorbente)
ANIOS = 25

# %% [markdown]
# ## Lectura de la matriz de transición
#
# Se intenta leer el Excel original. Si no está disponible, se usa la copia embebida, que es
# exactamente la misma matriz (las siete filas de rating más la fila absorbente de Default).

# %%
# Copia embebida de la matriz, tomada de matriz-ratings.xlsx
P_EMBEBIDA = np.array([
    [8.2391006512517184e-01, 1.3353189584925174e-01, 4.2329487544982128e-02, 2.2844851509747183e-04,
     1.0296059180067391e-07, 4.9046620032809458e-12, 3.8923065825545925e-16, 5.2162540949993651e-22],
    [3.2614393890106608e-01, 5.8132529071916961e-01, 7.6704584981381593e-02, 1.5798485602700266e-02,
     2.7651626199185096e-05, 4.8160505965289210e-08, 8.9770530011628408e-12, 2.3113048019581464e-16],
    [1.6702339019545639e-02, 1.7825992767066995e-01, 5.4255941699051646e-01, 2.4177087019767074e-01,
     2.0648738470714852e-02, 5.8457995938726237e-05, 2.4964499830894063e-07, 9.9454780735676494e-12],
    [4.9559035391988993e-05, 9.0075253433664557e-03, 3.9030448010163160e-01, 3.4068829165801195e-01,
     2.3608376114588217e-01, 2.3824728922789515e-02, 4.1438463870624148e-05, 2.1532905563759428e-07],
    [1.0325416795298516e-07, 1.4213536657130992e-04, 1.4813253751496924e-02, 9.2531870073681563e-02,
     6.3354916538207950e-01, 2.4603513875989436e-01, 1.2803845953136628e-02, 1.2448745897170936e-04],
    [1.5024787328214318e-11, 1.4168042336038897e-07, 2.3401435205193583e-04, 1.8384243568426096e-02,
     1.1761412431591850e-01, 3.5144206031069769e-01, 5.0612649291180389e-01, 6.1989228456536868e-03],
    [2.3732355844881274e-16, 1.4570893836673915e-11, 1.5543813213964283e-07, 5.9218757196752952e-05,
     5.9673240629386443e-03, 1.2054538504051282e-01, 5.1822768050504031e-01, 3.5520023618160818e-01],
    [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
])


def leer_matriz_del_excel(ruta):
    """Lee la matriz del Excel original localizando cada fila por su etiqueta.

    El fichero tiene las etiquetas en una columna y la suma de la fila en otra, y trae nueve
    filas de origen (Aaa, Aa, A, Baa, Ba, B, Caa, Ca-C, Default) frente a ocho columnas de
    destino. Se toman las siete de rating usando 'Caa' como estado agregado Caa-C, más la fila
    absorbente de Default; 'Ca-C' se descarta según el criterio explicado arriba.
    """
    from openpyxl import load_workbook
    hoja = load_workbook(ruta, data_only=True).active

    # Recogemos, por etiqueta, los ocho primeros números de cada fila
    por_etiqueta = {}
    for fila in hoja.iter_rows(values_only=True):
        etiqueta = next((c for c in fila if isinstance(c, str) and c.strip()), None)
        numeros = [c for c in fila if isinstance(c, (int, float))]
        if etiqueta and len(numeros) >= 8:
            por_etiqueta[etiqueta.strip()] = numeros[:8]

    queremos = ["Aaa", "Aa", "A", "Baa", "Ba", "B", "Caa", "Default"]
    faltan = [e for e in queremos if e not in por_etiqueta]
    if faltan:
        raise ValueError(f"no encuentro las filas: {faltan}  (hay: {list(por_etiqueta)})")

    descartadas = set(por_etiqueta) - set(queremos)
    print(f"filas descartadas del fichero: {sorted(descartadas)}")
    return np.array([por_etiqueta[e] for e in queremos])


ruta_excel = Path.home() / "Downloads" / "matriz-ratings (1).xlsx"
if ruta_excel.exists():
    P = leer_matriz_del_excel(ruta_excel)
    print(f"matriz leída de: {ruta_excel.name}")
    print(f"coincide con la copia embebida: {np.allclose(P, P_EMBEBIDA, atol=1e-15)}")
else:
    P = P_EMBEBIDA.copy()
    print("usando la copia embebida de la matriz")

# El fichero trae errores de redondeo del orden de 1e-16: normalizamos las filas.
desviacion = np.abs(P.sum(axis=1) - 1).max()
P = P / P.sum(axis=1, keepdims=True)
print(f"\ndesviación máxima de las filas respecto a 1 antes de normalizar: {desviacion:.3e}")
print(f"Default es absorbente: {P[D, D] == 1.0}")

# %% [markdown]
# ## Apartado 1.a — Probabilidad de *default* acumulada y marginal
#
# Como *Default* es absorbente, «estar en default en el año $n$» equivale a «haber hecho default
# en algún momento hasta el año $n$». La probabilidad acumulada es por tanto la columna de
# *Default* de $P^n$, y la marginal es su primera diferencia:
#
# $$\mathrm{PD}_i(n) = (P^{\,n})_{i,D}, \qquad d_i(n) = \mathrm{PD}_i(n) - \mathrm{PD}_i(n-1)$$

# %%
# Potencias sucesivas: potencias[n] = P^n, con potencias[0] = I
potencias = [np.eye(N)]
for n in range(1, ANIOS + 1):
    potencias.append(potencias[n - 1] @ P)

# pd_acum[i, n] con n = 1..25 (la columna 0 queda a cero y representa el año 0)
pd_acum = np.zeros((7, ANIOS + 1))
for i in range(7):
    for n in range(1, ANIOS + 1):
        pd_acum[i, n] = potencias[n][i, D]

pd_marg = np.diff(pd_acum, axis=1)          # pd_marg[i, n-1] = default exactamente en el año n

# Comprobación cruzada: d_i(n) = suma_k (P^{n-1})_{ik} p_{kD} para k != D
alternativa = np.array([[potencias[n - 1][i, :D] @ P[:D, D] for n in range(1, ANIOS + 1)]
                        for i in range(7)])
print(f"las dos formas de calcular la PD marginal coinciden: "
      f"{np.allclose(pd_marg, alternativa, atol=1e-18)}")
print(f"error máximo entre ambas: {np.abs(pd_marg - alternativa).max():.3e}")

# %%
print("PD ACUMULADA (%)\n")
print("Año  " + "".join(f"{r:>12}" for r in ESTADOS[:7]))
for n in [1, 2, 3, 5, 10, 15, 20, 25]:
    print(f"{n:>3}  " + "".join(f"{100 * pd_acum[i, n]:>12.6f}" for i in range(7)))

print("\n\nPD MARGINAL — default exactamente en ese año (%)\n")
print("Año  " + "".join(f"{r:>12}" for r in ESTADOS[:7]))
for n in [1, 2, 3, 5, 10, 15, 20, 25]:
    print(f"{n:>3}  " + "".join(f"{100 * pd_marg[i, n - 1]:>12.6f}" for i in range(7)))

# %% [markdown]
# ### Por qué las curvas tienen aspecto distinto
#
# El máximo de la PD marginal se desplaza hacia el futuro conforme mejora la calidad crediticia.

# %%
print("Año en que la PD marginal alcanza su máximo (dentro de la ventana de 25 años)\n")
for i, r in enumerate(ESTADOS[:7]):
    k = int(np.argmax(pd_marg[i])) + 1
    nota = "  (sigue creciendo: el máximo real cae más allá del año 25)" if k == ANIOS else ""
    print(f"  {r:<7} año {k:>2}   valor {100 * pd_marg[i, k - 1]:>7.4f} %{nota}")

# %% [markdown]
# - **Ratings bajos (Caa-C, B).** La curva decrece desde el primer año: el riesgo es inmediato y
#   quien sobrevive lo hace, en buena medida, porque ha migrado hacia arriba.
# - **Ratings intermedios (Baa, Ba, A).** Aparece una joroba a medio plazo: la compañía necesita
#   degradarse varios escalones antes de poder quebrar, y ese tránsito lleva tiempo.
# - **Ratings altos (Aaa, Aa).** La curva es prácticamente creciente en toda la ventana: quebrar
#   el primer año exige siete degradaciones consecutivas, con probabilidad del orden de $10^{-22}$.

# %%
import matplotlib.pyplot as plt

plt.rcParams["figure.dpi"] = 110

anios = np.arange(1, ANIOS + 1)
fig, ejes = plt.subplots(1, 2, figsize=(13, 4.5))

for i, r in enumerate(ESTADOS[:7]):
    ejes[0].plot(anios, 100 * pd_marg[i], marker="o", ms=3, label=r)
    ejes[1].semilogy(anios, 100 * pd_marg[i], marker="o", ms=3, label=r)

ejes[0].set(xlabel="año n", ylabel="P(default en el año n)  %",
            title="PD marginal — escala lineal")
ejes[1].set(xlabel="año n", ylabel="P(default en el año n)  %",
            title="PD marginal — escala logarítmica")
for e in ejes:
    e.grid(alpha=.3)
    e.legend(fontsize=8)
plt.tight_layout()
plt.show()

# %%
fig, eje = plt.subplots(figsize=(7.5, 4.5))
for i, r in enumerate(ESTADOS[:7]):
    eje.plot(anios, 100 * pd_acum[i, 1:], marker="o", ms=3, label=r)
eje.set(xlabel="año n", ylabel="P(default hasta el año n)  %",
        title="Probabilidad acumulada de default")
eje.grid(alpha=.3)
eje.legend(fontsize=8)
plt.tight_layout()
plt.show()

# %% [markdown]
# ## Apartado 1.b — Cohorte de 5.002 compañías
#
# Condicionando en el *rating* inicial (ley de la probabilidad total), la proporción de la cohorte
# que quiebra en el año $n$ es la media ponderada de las PD marginales:
#
# $$d^{\,\text{coh}}(n) = \sum_i w_i\, d_i(n), \qquad w_i = n_i / N$$
#
# El número esperado de compañías es $N \cdot d^{\,\text{coh}}(n)$. Por linealidad de la esperanza
# esto es exacto aunque las compañías no sean independientes; la independencia solo haría falta
# para estudiar la dispersión del total, que aquí no se pide.

# %%
cohorte = np.array([136, 694, 1298, 1175, 578, 817, 304])
TOTAL = cohorte.sum()
w = cohorte / TOTAL

print(f"cohorte: {TOTAL} compañías\n")
for r, n_i, w_i in zip(ESTADOS[:7], cohorte, w):
    print(f"  {r:<7} {n_i:>5}   {100 * w_i:>6.3f} %")

coh_marg = w @ pd_marg                       # proporción que quiebra en cada año
coh_acum = np.cumsum(coh_marg)

print("\n\nAño   Prop. del año      Nº esperado     Prop. acumulada     Nº acumulado")
for n in range(1, ANIOS + 1):
    print(f"{n:>3}    {100 * coh_marg[n-1]:>10.4f} %   {TOTAL * coh_marg[n-1]:>10.2f}   "
          f"{100 * coh_acum[n-1]:>13.4f} %   {TOTAL * coh_acum[n-1]:>12.2f}")

pico = int(np.argmax(coh_marg)) + 1
print(f"\nmáximo anual en el año {pico}: {TOTAL * coh_marg[pico-1]:.2f} compañías "
      f"({100 * coh_marg[pico-1]:.4f} %)")
print(f"acumulado a 25 años: {TOTAL * coh_acum[-1]:.2f} compañías "
      f"({100 * coh_acum[-1]:.4f} % de la cohorte)")

# %%
fig, eje = plt.subplots(figsize=(8, 4))
eje.bar(anios, TOTAL * coh_marg, color="#3b6ea5")
eje.set(xlabel="año n", ylabel="compañías esperadas",
        title=f"Cohorte de {TOTAL} compañías: defaults esperados por año")
eje.grid(alpha=.3, axis="y")
plt.tight_layout()
plt.show()

# %% [markdown]
# ## Apartado 1.c — Distribución del *rating* a 25 años
#
# Partiendo de un rating conocido, la distribución es la fila correspondiente de $P^{25}$. Si la
# compañía se elige al azar dentro de la cohorte, es la mezcla $\pi_{25} = w^{\top} P^{25}$.

# %%
P25 = potencias[25]

print("DISTRIBUCIÓN A 25 AÑOS (%)\n")
print(f"{'Origen':<9}" + "".join(f"{r:>10}" for r in ESTADOS))
for i, r in enumerate(ESTADOS[:7]):
    print(f"{r:<9}" + "".join(f"{100 * P25[i, j]:>10.4f}" for j in range(N)))

pi_cohorte = w @ P25[:7]
print(f"{'Cohorte':<9}" + "".join(f"{100 * v:>10.4f}" for v in pi_cohorte))

# %% [markdown]
# Un rasgo llamativo: **condicionadas a sobrevivir**, las distribuciones son casi idénticas para
# todos los orígenes. Es el comportamiento esperado de una cadena con un único estado absorbente:
# la parte transitoria converge a la distribución cuasi-estacionaria.

# %%
print("Distribución condicionada a NO haber quebrado (%)\n")
print(f"{'Origen':<9}" + "".join(f"{r:>10}" for r in ESTADOS[:7]))
for i, r in enumerate(ESTADOS[:7]):
    vivos = P25[i, :7] / P25[i, :7].sum()
    print(f"{r:<9}" + "".join(f"{100 * v:>10.2f}" for v in vivos))

# %% [markdown]
# ### Comprobación por simulación
#
# Simulamos trayectorias completas de la cadena por el método de la transformada inversa: en cada
# año se sortea $U \sim \mathcal U(0,1)$ y se salta al estado $j$ tal que
# $\sum_{k<j} p_{Rk} \le U < \sum_{k\le j} p_{Rk}$.

# %%
CAMINOS = 200_000
rng = np.random.default_rng(20260907)
acumuladas = P.cumsum(axis=1)                # acumuladas[i] = CDF de la fila i

print(f"simulando {CAMINOS:,} trayectorias de 25 años desde cada rating...\n")

simulado = np.zeros((7, N))
for origen in range(7):
    estado = np.full(CAMINOS, origen)
    for _ in range(ANIOS):
        u = rng.random(CAMINOS)
        # búsqueda vectorizada del primer índice cuya acumulada supera u
        nuevo = (u[:, None] >= acumuladas[estado]).sum(axis=1)
        estado = np.minimum(nuevo, N - 1)
    simulado[origen] = np.bincount(estado, minlength=N) / CAMINOS

print(f"{'Origen':<9}{'':>3}" + "".join(f"{r:>10}" for r in ESTADOS) + f"{'chi2':>10}")
for i, r in enumerate(ESTADOS[:7]):
    esperado = P25[i] * CAMINOS
    observado = simulado[i] * CAMINOS
    valido = esperado > 5                     # celdas con frecuencia esperada suficiente
    chi2 = (((observado[valido] - esperado[valido]) ** 2) / esperado[valido]).sum()
    print(f"{r:<9}{'teo':>3}" + "".join(f"{100 * P25[i, j]:>10.4f}" for j in range(N)))
    print(f"{'':<9}{'sim':>3}" + "".join(f"{100 * simulado[i, j]:>10.4f}" for j in range(N))
          + f"{chi2:>10.2f}")

print("\nValores críticos de una chi-cuadrado con 7 grados de libertad: 14.07 (5 %), 18.48 (1 %).")

# %%
fig, ejes = plt.subplots(1, 2, figsize=(13, 4))
for eje, origen in zip(ejes, [0, 6]):
    x = np.arange(N)
    eje.bar(x - 0.2, 100 * P25[origen], 0.4, label="teórica ($P^{25}$)", color="#2a5783")
    eje.bar(x + 0.2, 100 * simulado[origen], 0.4, label=f"simulada ({CAMINOS:,})", color="#d1762f")
    eje.set(xticks=x, xticklabels=ESTADOS, ylabel="probabilidad  %",
            title=f"Distribución a 25 años desde {ESTADOS[origen]}")
    eje.tick_params(axis="x", rotation=45)
    eje.legend(fontsize=8)
    eje.grid(alpha=.3, axis="y")
plt.tight_layout()
plt.show()

# %% [markdown]
# ## Resumen del ejercicio 1

# %%
print(f"1.a)  PD acumulada a 25 años por rating:")
for i, r in enumerate(ESTADOS[:7]):
    print(f"        {r:<7} {100 * pd_acum[i, 25]:>8.4f} %")
print(f"\n1.b)  Cohorte de {TOTAL} compañías:")
print(f"        año 1  ..... {TOTAL * coh_marg[0]:>8.2f} defaults ({100 * coh_marg[0]:.4f} %)")
print(f"        año 2  ..... {TOTAL * coh_marg[1]:>8.2f} defaults  <- máximo anual")
print(f"        25 años .... {TOTAL * coh_acum[-1]:>8.2f} defaults ({100 * coh_acum[-1]:.4f} %)")
print(f"\n1.c)  Probabilidad de estar en default a 25 años, compañía al azar de la cohorte:"
      f" {100 * pi_cohorte[D]:.4f} %")

# %%
# Volcado de resultados para la memoria
import csv
salida = Path.cwd() / "resultados"
salida.mkdir(exist_ok=True)

with open(salida / "ej1_pd.csv", "w", newline="", encoding="utf-8") as f:
    escritor = csv.writer(f, delimiter=";")
    escritor.writerow(["Anio"] + [f"PDacum_{r}" for r in ESTADOS[:7]]
                                + [f"PDmarg_{r}" for r in ESTADOS[:7]])
    for n in range(1, ANIOS + 1):
        escritor.writerow([n] + [repr(pd_acum[i, n]) for i in range(7)]
                              + [repr(pd_marg[i, n - 1]) for i in range(7)])

with open(salida / "ej1_cohorte.csv", "w", newline="", encoding="utf-8") as f:
    escritor = csv.writer(f, delimiter=";")
    escritor.writerow(["Anio", "Prop_exacta", "Prop_acum", "Num_esperado", "Num_acum"])
    for n in range(1, ANIOS + 1):
        escritor.writerow([n, repr(coh_marg[n-1]), repr(coh_acum[n-1]),
                           f"{TOTAL * coh_marg[n-1]:.6f}", f"{TOTAL * coh_acum[n-1]:.6f}"])

print(f"resultados escritos en {salida}")
