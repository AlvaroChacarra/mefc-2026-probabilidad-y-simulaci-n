"""Convierte los ficheros .py con marcadores `# %%` en notebooks .ipynb y los ejecuta.

Uso:  python construir_notebooks.py
"""
import re
import sys
from pathlib import Path

import nbformat
from nbformat.v4 import new_notebook, new_code_cell, new_markdown_cell
from nbclient import NotebookClient

AQUI = Path(__file__).parent
FUENTES = ["ej1_ratings.py", "ej2_ito.py", "ej3_opciones.py"]


def trocear(texto):
    """Parte el fichero en celdas segun los marcadores # %% y # %% [markdown]."""
    lineas = texto.splitlines()
    celdas, actual, es_md = [], [], False

    def cerrar():
        if actual:
            cuerpo = "\n".join(actual).strip("\n")
            if cuerpo.strip():
                celdas.append(("markdown" if es_md else "code", cuerpo))

    for linea in lineas:
        marca = re.match(r"^#\s*%%(.*)$", linea)
        if marca:
            cerrar()
            actual, es_md = [], "[markdown]" in marca.group(1)
            continue
        if es_md:
            # en markdown las lineas van comentadas con "# "
            actual.append(re.sub(r"^#\s?", "", linea))
        else:
            actual.append(linea)
    cerrar()
    return celdas


def construir(fuente):
    texto = (AQUI / fuente).read_text(encoding="utf-8")
    nb = new_notebook()
    for tipo, cuerpo in trocear(texto):
        nb.cells.append(new_markdown_cell(cuerpo) if tipo == "markdown"
                        else new_code_cell(cuerpo))
    nb.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3",
                                 "language": "python"}
    nb.metadata["language_info"] = {"name": "python"}
    return nb


def main():
    for fuente in FUENTES:
        destino = AQUI / fuente.replace(".py", ".ipynb")
        nb = construir(fuente)
        n_md = sum(1 for c in nb.cells if c.cell_type == "markdown")
        n_code = sum(1 for c in nb.cells if c.cell_type == "code")
        print(f"{fuente:<20} -> {destino.name:<22} {n_md} celdas de texto, "
              f"{n_code} de codigo", flush=True)

        cliente = NotebookClient(nb, timeout=3600, kernel_name="python3",
                                 resources={"metadata": {"path": str(AQUI)}})
        cliente.execute()

        errores = [c for c in nb.cells
                   if c.cell_type == "code"
                   and any(o.get("output_type") == "error" for o in c.get("outputs", []))]
        figuras = sum(1 for c in nb.cells for o in c.get("outputs", [])
                      if "image/png" in o.get("data", {}))
        nbformat.write(nb, destino)
        estado = f"ERRORES en {len(errores)} celdas" if errores else "sin errores"
        print(f"{'':<20}    ejecutado: {estado}, {figuras} figuras\n", flush=True)
        if errores:
            for c in errores:
                for o in c.outputs:
                    if o.get("output_type") == "error":
                        print("   ", o.get("ename"), o.get("evalue"))
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
