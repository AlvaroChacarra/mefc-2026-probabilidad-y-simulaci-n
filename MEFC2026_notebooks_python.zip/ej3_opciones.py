# %% [markdown]
# # Ejercicio 3 — Volatilidad determinista dependiente del tiempo
#
# **MEFC 2026 · Procesos estocásticos**
#
# Datos: $S_0 = 100$, $K = 100$, $r = 1\,\%$ y tres *calls* europeas ATM de mercado.
#
# $$dS_t = r\,S_t\,dt + \sigma(t)\,S_t\,dW_t, \qquad \sigma(t) = at^2 + bt + c$$

# %%
import numpy as np
import matplotlib.pyplot as plt
from math import erf, sqrt, log, exp

plt.rcParams["figure.dpi"] = 110

S0, K, r = 100.0, 100.0, 0.01
VENCIMIENTOS = np.array([1.00, 1.25, 2.00])
PRECIOS_MERCADO = np.array([9.55, 12.48, 23.36])


def Phi(x):
    """Función de distribución de una normal estándar."""
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


Phi_vec = np.vectorize(Phi)

# %% [markdown]
# ## Apartado 3.1 — La expresión (2) resuelve la ecuación (1)
#
# Sea $V(t) = \int_0^t \sigma(s)^2 ds$ la varianza total acumulada y
#
# $$Y_t = rt - \tfrac12 V(t) + \int_0^t \sigma(s)\,dW_s, \qquad S_t = S_0 e^{Y_t}$$
#
# Entonces $dY_t = (r - \tfrac12\sigma(t)^2)dt + \sigma(t)dW_t$ y
# $d\langle Y\rangle_t = \sigma(t)^2 dt$. Aplicando Itô a $f(y) = S_0 e^y$ (con $f' = f'' = S_t$):
#
# $$dS_t = S_t\,dY_t + \tfrac12 S_t\,d\langle Y\rangle_t
#        = S_t\Big[\big(r - \tfrac12\sigma^2\big)dt + \sigma\,dW_t + \tfrac12\sigma^2 dt\Big]
#        = r S_t\,dt + \sigma(t) S_t\,dW_t$$
#
# El término $-\tfrac12\int\sigma^2$ es exactamente la corrección de Itô que compensa la
# convexidad de la exponencial. La demostración no usa que $\sigma$ sea constante, solo que sea
# determinista y localmente de cuadrado integrable.

# %% [markdown]
# ## Apartado 3.2 — Fórmula analítica de la *call*
#
# Como $\sigma(\cdot)$ es determinista, la integral de Wiener $\int_0^T\sigma\,dW$ es **gaussiana**
# de media 0 y varianza $V(T)$ (isometría de Itô). Por tanto
#
# $$\ln\frac{S_T}{S_0} \sim \mathcal N\Big(rT - \tfrac12 V(T),\; V(T)\Big)$$
#
# que es la misma ley que en Black-Scholes identificando $\bar\sigma^2 T \leftrightarrow V(T)$:
#
# $$\boxed{\;C = S_0\Phi(d_1) - Ke^{-rT}\Phi(d_2), \quad
#   d_1 = \frac{\ln(S_0/K) + rT + \tfrac12 V}{\sqrt V}, \quad d_2 = d_1 - \sqrt V\;}$$

# %%
def call_bs(V, T, S0=S0, K=K, r=r):
    """Call europea con varianza total acumulada V = int_0^T sigma(s)^2 ds."""
    if V <= 0:
        return max(S0 - K * exp(-r * T), 0.0)
    s = sqrt(V)
    d1 = (log(S0 / K) + r * T + 0.5 * V) / s
    return S0 * Phi(d1) - K * exp(-r * T) * Phi(d1 - s)


def vega_en_V(V, T, S0=S0, K=K, r=r):
    """Derivada del precio respecto a V (siempre positiva: la inversion es unica)."""
    s = sqrt(V)
    d1 = (log(S0 / K) + r * T + 0.5 * V) / s
    return S0 * exp(-0.5 * d1**2) / sqrt(2 * np.pi) / (2 * s)


# Comprobacion: con sigma constante recuperamos Black-Scholes clasico
sig, T = 0.25, 1.5
print(f"sigma constante {sig} a T = {T}:")
print(f"  con V = sigma^2 T : {call_bs(sig**2 * T, T):.10f}")
print(f"  Black-Scholes     : {call_bs(sig**2 * T, T):.10f}   (identico por construccion)")

# %% [markdown]
# ## Apartado 3.3 — Calibración de $\sigma(t) = at^2 + bt + c$
#
# ### Paso 1: varianzas totales implícitas
#
# Cada precio determina un único $V(T_i)$ porque $C$ es estrictamente creciente en $V$
# ($\partial C/\partial V = S_0\varphi(d_1)/(2\sqrt V) > 0$). Invertimos por Newton.

# %%
def V_implicita(precio, T, V0=0.05, tol=1e-15, maxit=100):
    """Invierte la formula de la call para obtener la varianza total acumulada."""
    V = V0
    for _ in range(maxit):
        f = call_bs(V, T) - precio
        if abs(f) < tol:
            break
        V -= f / vega_en_V(V, T)
        V = max(V, 1e-12)
    return V


V_mercado = np.array([V_implicita(p, T) for p, T in zip(PRECIOS_MERCADO, VENCIMIENTOS)])

print(f"{'T':>6}{'precio':>10}{'V(T) implicita':>20}{'vol. plana':>14}{'vol. forward':>15}")
V_prev, T_prev = 0.0, 0.0
for T, p, V in zip(VENCIMIENTOS, PRECIOS_MERCADO, V_mercado):
    fwd = sqrt((V - V_prev) / (T - T_prev))
    print(f"{T:>6.2f}{p:>10.2f}{V:>20.10f}{sqrt(V/T):>13.4%}{fwd:>15.4%}")
    V_prev, T_prev = V, T

print("\nLas varianzas forward son positivas: los tres precios son mutuamente coherentes")
print("(no hay arbitraje calendario) y existe un sigma(t) real que los reproduce.")

# %% [markdown]
# ### Paso 2: el sistema no lineal
#
# Desarrollando el cuadrado del polinomio e integrando término a término:
#
# $$V(T) = \frac{a^2}{5}T^5 + \frac{ab}{2}T^4 + \frac{b^2+2ac}{3}T^3 + bc\,T^2 + c^2 T$$
#
# Resolvemos $V(1) = V_1$, $V(1.25) = V_2$, $V(2) = V_3$ por el método de Newton en $\mathbb R^3$.

# %%
def V_polinomio(coef, T):
    """Varianza acumulada de sigma(t) = a t^2 + b t + c."""
    a, b, c = coef
    return (a*a/5*T**5 + a*b/2*T**4 + (b*b + 2*a*c)/3*T**3 + b*c*T**2 + c*c*T)


def residuo(coef):
    return np.array([V_polinomio(coef, T) for T in VENCIMIENTOS]) - V_mercado


def newton3(inicio, tol=1e-14, maxit=200):
    """Newton con jacobiano por diferencias finitas."""
    p = np.array(inicio, dtype=float)
    for _ in range(maxit):
        F = residuo(p)
        J = np.empty((3, 3))
        for k in range(3):
            h = 1e-7
            q = p.copy(); q[k] += h
            J[:, k] = (residuo(q) - F) / h
        try:
            paso = np.linalg.solve(J, -F)
        except np.linalg.LinAlgError:
            return None
        p += paso
        if np.linalg.norm(paso) < tol:
            return p if np.sum(residuo(p)**2) < 1e-20 else None
    return None


# Arranque: parabola por las tres volatilidades forward en el punto medio de su tramo
puntos_t = [0.5, 1.125, 1.625]
puntos_s = []
V_prev, T_prev = 0.0, 0.0
for T, V in zip(VENCIMIENTOS, V_mercado):
    puntos_s.append(sqrt((V - V_prev) / (T - T_prev)))
    V_prev, T_prev = V, T
arranque = np.linalg.solve(np.array([[t**2, t, 1] for t in puntos_t]), np.array(puntos_s))
print(f"arranque (parabola por las vol. forward): a={arranque[0]:.6f}  b={arranque[1]:.6f}  "
      f"c={arranque[2]:.6f}\n")

coef = newton3(arranque)
a, b, c = coef
print(f"SOLUCION CALIBRADA")
print(f"  a = {a:.12f}")
print(f"  b = {b:.12f}")
print(f"  c = {c:.12f}")
print(f"\n  sigma(t) = {a:.8f} t^2 + {b:.8f} t + {c:.8f}")
print(f"\n  suma de errores al cuadrado: {np.sum(residuo(coef)**2):.3e}")

# %%
print("COMPROBACION: reprecio de las tres calls con la volatilidad calibrada\n")
print(f"{'T':>6}{'V(T) calibrada':>20}{'V(T) implicita':>20}{'modelo':>14}{'mercado':>10}")
for T, V_m, p in zip(VENCIMIENTOS, V_mercado, PRECIOS_MERCADO):
    V_c = V_polinomio(coef, T)
    print(f"{T:>6.2f}{V_c:>20.12f}{V_m:>20.12f}{call_bs(V_c, T):>14.8f}{p:>10.2f}")

print(f"\nPositividad: el vertice de la parabola esta en t = {-b/(2*a):.4f}, fuera de [0, 2].")
for t in [0.0, 0.5, 1.0, 1.5, 2.0]:
    print(f"  sigma({t:.1f}) = {a*t*t + b*t + c:>8.4%}")

# %% [markdown]
# Los coeficientes son sospechosamente próximos a $(0.05,\ 0.20,\ 0.10)$. Con esos valores redondos
# los precios teóricos redondean exactamente a los tres del enunciado: los datos se generaron con
# esa parábola y la calibración la recupera.

# %%
redondos = np.array([0.05, 0.20, 0.10])
print(f"{'T':>6}{'precio con (0.05, 0.20, 0.10)':>32}{'redondeado':>13}{'enunciado':>12}")
for T, p in zip(VENCIMIENTOS, PRECIOS_MERCADO):
    pr = call_bs(V_polinomio(redondos, T), T)
    print(f"{T:>6.2f}{pr:>32.6f}{round(pr, 2):>13.2f}{p:>12.2f}")

# %% [markdown]
# ### Unicidad de la solución
#
# $V$ solo depende de $(a,b,c)$ a través de productos de pares, luego $(-a,-b,-c)$ es también
# solución (misma ley para $S$). Un barrido multiarranque encuentra todas las raíces reales.

# %%
raices = []
for a0 in [-0.6, -0.3, -0.1, 0.05, 0.2, 0.5]:
    for b0 in [-0.8, -0.3, 0.05, 0.2, 0.6]:
        for c0 in [-0.5, -0.1, 0.1, 0.4]:
            sol = newton3([a0, b0, c0])
            if sol is None:
                continue
            if not any(np.linalg.norm(sol - v) < 1e-6 for v in raices):
                raices.append(sol)

rejilla_t = np.linspace(0, 2, 1001)
print(f"raices algebraicas distintas: {len(raices)}\n")
admisibles = []
for v in sorted(raices, key=lambda z: z[0]):
    s = v[0] * rejilla_t**2 + v[1] * rejilla_t + v[2]
    if s.min() < -1e-12 and s.max() > 1e-12:
        tipo = "CRUZA CERO"
    elif s.max() <= 1e-12:
        tipo = "toda negativa"
    else:
        tipo = "toda positiva"
        admisibles.append(v)
    print(f"  a={v[0]:+.9f}  b={v[1]:+.9f}  c={v[2]:+.9f}   -> {tipo}")

print(f"\nSolo {len(admisibles)} raiz cumple sigma(t) > 0 en todo [0, 2]: es la elegida.")

# %%
fig, ejes = plt.subplots(1, 2, figsize=(13, 4.3))

ejes[0].plot(rejilla_t, a * rejilla_t**2 + b * rejilla_t + c, lw=2, color="#2a5783",
             label=r"$\sigma(t)$ calibrada")
ejes[0].scatter(VENCIMIENTOS, np.sqrt(V_mercado / VENCIMIENTOS), color="#d1762f", zorder=5,
                label="vol. implícita plana de mercado")
ejes[0].set(xlabel="t (años)", ylabel=r"$\sigma(t)$", title="Volatilidad instantánea calibrada")

rejilla_V = np.array([V_polinomio(coef, t) for t in rejilla_t])
ejes[1].plot(rejilla_t, rejilla_V, lw=2, color="#2a5783", label="V(T) del modelo")
ejes[1].scatter(VENCIMIENTOS, V_mercado, color="#d1762f", zorder=5, label="V(T) de las 3 calls")
ejes[1].set(xlabel="T (años)", ylabel="V(T)", title="Varianza total acumulada")

for e in ejes:
    e.legend(fontsize=9)
    e.grid(alpha=.3)
plt.tight_layout()
plt.show()

# %% [markdown]
# ## Apartado 3.4 — Opción asiática por simulación
#
# La opción paga en $T_p = 2$ años
#
# $$\Pi = \Big(\tfrac14\sum_{i=1}^{4} S_{t_i} - K\Big)^{+},
#   \qquad t_i \in \{1.15,\ 1.30,\ 1.60,\ 1.70\}$$
#
# Ojo: el pago es en $T_p = 2$ aunque la última fijación sea en $t_4 = 1.7$, así que se descuenta
# con $e^{-0.01\cdot 2}$.
#
# ### Simulación exacta
#
# No hace falta discretizar la EDE. Como $\sigma$ es determinista, el vector de log-precios es
# gaussiano y se genera **exactamente**:
#
# $$S_{t_i} = S_0\exp\Big(r t_i - \tfrac12 V(t_i) + X_i\Big), \qquad
#   X_i = X_{i-1} + \sqrt{V(t_i) - V(t_{i-1})}\;Z_i$$

# %%
FIJACIONES = np.array([1.15, 1.30, 1.60, 1.70])
T_PAGO = 2.0

V_fij = np.array([V_polinomio(coef, t) for t in FIJACIONES])
saltos = np.sqrt(np.diff(np.concatenate([[0.0], V_fij])))

print(f"{'i':>3}{'t_i':>8}{'sigma(t_i)':>14}{'V(t_i)':>16}{'salto de V':>15}"
      f"{'desv. tipica':>15}{'E[S_ti]':>14}")
for i, t in enumerate(FIJACIONES):
    print(f"{i+1:>3}{t:>8.2f}{a*t*t + b*t + c:>14.8f}{V_fij[i]:>16.8f}"
          f"{(V_fij[i] - (V_fij[i-1] if i else 0)):>15.8f}{saltos[i]:>15.8f}"
          f"{S0 * exp(r * t):>14.6f}")

# %% [markdown]
# ### Reducción de varianza
#
# Dos técnicas: **variables antitéticas** (cada sorteo se usa también con signo cambiado) y una
# **variable de control** basada en la asiática geométrica $G = (\prod_i S_{t_i})^{1/4}$, cuyo
# logaritmo es exactamente gaussiano y cuyo precio tiene fórmula cerrada.

# %%
def precio_geometrico_exacto():
    """Precio analitico de la call sobre la media geometrica de las 4 fijaciones."""
    n = len(FIJACIONES)
    m = log(S0) + np.mean(r * FIJACIONES - 0.5 * V_fij)
    # Cov(X_i, X_j) = V(t_min(i,j))
    cov = np.minimum.outer(V_fij, V_fij)
    v = cov.sum() / n**2
    d1 = (m + v - log(K)) / sqrt(v)
    return exp(-r * T_PAGO) * (exp(m + v / 2) * Phi(d1) - K * Phi(d1 - sqrt(v)))


C_geo = precio_geometrico_exacto()
print(f"precio exacto de la asiatica geometrica: {C_geo:.8f}")

# %%
def simular_asiatica(parejas=1_000_000, semilla=20260907, bloque=250_000):
    """Monte Carlo antitetico. Devuelve los payoffs descontados aritmetico y geometrico."""
    rng = np.random.default_rng(semilla)
    arit, geom = [], []
    hechas = 0
    while hechas < parejas:
        n = min(bloque, parejas - hechas)
        Z = rng.standard_normal((n, 4))
        for signo in (1.0, -1.0):
            X = np.cumsum(signo * saltos * Z, axis=1)
            S = S0 * np.exp(r * FIJACIONES - 0.5 * V_fij + X)
            arit.append(np.maximum(S.mean(axis=1) - K, 0.0) * exp(-r * T_PAGO))
            geom.append(np.maximum(np.exp(np.log(S).mean(axis=1)) - K, 0.0) * exp(-r * T_PAGO))
        hechas += n
    return np.concatenate(arit), np.concatenate(geom)


print("simulando 1.000.000 de parejas antiteticas (2.000.000 de caminos)...")
pago_arit, pago_geom = simular_asiatica()
n_caminos = len(pago_arit)

precio_simple = pago_arit.mean()
ee_simple = pago_arit.std(ddof=1) / sqrt(n_caminos)

beta = np.cov(pago_arit, pago_geom, ddof=1)[0, 1] / pago_geom.var(ddof=1)
corregido = pago_arit - beta * (pago_geom - C_geo)
precio_cv = corregido.mean()
ee_cv = corregido.std(ddof=1) / sqrt(n_caminos)

print(f"\n{'estimador':<34}{'precio':>12}{'error estandar':>17}{'IC 95 %':>26}")
print(f"{'Monte Carlo antitetico':<34}{precio_simple:>12.4f}{ee_simple:>17.6f}"
      f"   [{precio_simple - 1.96*ee_simple:.4f}, {precio_simple + 1.96*ee_simple:.4f}]")
print(f"{'+ control geometrico':<34}{precio_cv:>12.4f}{ee_cv:>17.6f}"
      f"   [{precio_cv - 1.96*ee_cv:.4f}, {precio_cv + 1.96*ee_cv:.4f}]")
print(f"\nreduccion de varianza: factor {(ee_simple/ee_cv)**2:.0f}   (beta = {beta:.6f})")

# %% [markdown]
# ### Comprobaciones de coherencia

# %%
media_A_teorica = np.mean(S0 * np.exp(r * FIJACIONES))
Z = np.random.default_rng(1).standard_normal((400_000, 4))
X = np.cumsum(saltos * Z, axis=1)
media_A_simulada = (S0 * np.exp(r * FIJACIONES - 0.5 * V_fij + X)).mean(axis=1).mean()

call_europea_17 = call_bs(V_polinomio(coef, 1.7), 1.7)

print(f"1) E[media de las fijaciones]")
print(f"     teorica  {media_A_teorica:.6f}   simulada {media_A_simulada:.6f}")
print(f"     (el descontado es martingala: el generador es insesgado)\n")
print(f"2) geometrica < aritmetica  (desigualdad de las medias)")
print(f"     {C_geo:.4f} < {precio_cv:.4f}   -> {C_geo < precio_cv}\n")
print(f"3) la asiatica cuesta menos que una europea del entorno de las fijaciones")
print(f"     europea ATM a T = 1.7: {call_europea_17:.4f}  >  asiatica {precio_cv:.4f}")

# %%
# Convergencia del estimador
paso = max(1, n_caminos // 400)
acumulada = np.cumsum(pago_arit[::paso]) / np.arange(1, len(pago_arit[::paso]) + 1)
ejes_x = np.arange(1, len(acumulada) + 1) * paso

fig, eje = plt.subplots(figsize=(8.5, 4))
eje.plot(ejes_x, acumulada, lw=1, color="#2a5783")
eje.axhline(precio_cv, color="#a02c2c", ls="--", lw=1.4, label=f"valor final {precio_cv:.4f}")
eje.set(xlabel="número de caminos", ylabel="precio estimado",
        title="Convergencia del Monte Carlo", ylim=(precio_cv - .12, precio_cv + .12))
eje.legend()
eje.grid(alpha=.3)
plt.tight_layout()
plt.show()

# %% [markdown]
# ### El criterio de selección de la curva importa
#
# Las raíces que cruzan cero repricia igual las tres *calls* europeas (solo dependen de $V(T_i)$),
# pero dan un precio distinto para la asiática, que depende de toda la trayectoria de $V$.

# %%
print(f"{'curva':<42}{'asiatica':>12}")
for v in sorted(raices, key=lambda z: z[0]):
    s = v[0] * rejilla_t**2 + v[1] * rejilla_t + v[2]
    tipo = "cruza cero" if (s.min() < -1e-12 < 1e-12 < s.max()) else \
           ("toda negativa" if s.max() <= 1e-12 else "toda positiva")
    Vf = np.array([V_polinomio(v, t) for t in FIJACIONES])
    sal = np.sqrt(np.maximum(np.diff(np.concatenate([[0.0], Vf])), 0))
    rng = np.random.default_rng(99)
    Zc = rng.standard_normal((300_000, 4))
    tot = 0.0
    for signo in (1.0, -1.0):
        Xc = np.cumsum(signo * sal * Zc, axis=1)
        Sc = S0 * np.exp(r * FIJACIONES - 0.5 * Vf + Xc)
        tot += np.maximum(Sc.mean(axis=1) - K, 0).mean() * exp(-r * T_PAGO)
    etiqueta = f"a={v[0]:+.4f} b={v[1]:+.4f} c={v[2]:+.4f} [{tipo}]"
    print(f"{etiqueta:<42}{tot/2:>12.4f}")

# %% [markdown]
# ## Resumen del ejercicio 3

# %%
print(f"3.1)  Ito sobre S_0 exp(Y_t) devuelve dS = r S dt + sigma(t) S dW.")
print(f"3.2)  Black-Scholes con sigma^2 T sustituido por V(T) = int_0^T sigma(s)^2 ds.")
print(f"3.3)  a = {a:.9f}   b = {b:.9f}   c = {c:.9f}")
print(f"      reprecia las tres calls con SSE = {np.sum(residuo(coef)**2):.2e}")
print(f"3.4)  Precio de la asiatica: {precio_cv:.4f}  +/- {1.96*ee_cv:.4f}  (95 %)")
print(f"      -> {precio_cv:.2f} unidades monetarias")
